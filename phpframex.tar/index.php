<?php
    error_reporting(E_ALL);
    ini_set('display_errors',0);
    session_start();
    require('PHPFramex.php');
    require('routes.php')
?>
