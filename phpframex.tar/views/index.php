<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/views/css/styles.css">
    <title>Home</title>
</head>
<body>
<div class="main">
    <div class="row">
    <h3>Está página mostrará el enlace de la lista de tareas realizadas en el curso de programación web.</h3>
    <br>
    <div class="row">
        <ul>
            <li> <h2><a href="booksOld"> Tarea 1</a></h2></li>               
            <br> 
            <li><h2><a href="publishers">Tarea 2</a></h2>
            
                <ul style="margin-left:45px; margin-top:15px;">
                    <li> <a href="views/images/tarea2/diagrama.jpg">Diagrama </a></li>
                </ul>
            </li>
        </ul>
    </div>
    
  
  
  
</div>
</div>
</body>
</html>