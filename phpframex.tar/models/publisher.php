<?php
// file: models/publisher.php

class Publisher extends Model {
  protected static $table = 'publisher';
  
}
?>