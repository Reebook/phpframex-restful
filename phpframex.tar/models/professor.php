<?php
// file: models/Professor.php

class Professor extends Model {
  protected static $table = 'professor';
  
}
?>