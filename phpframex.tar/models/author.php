<?php
// file: models/author.php

class Author extends Model {
  protected static $table = 'author';
  
}
?>