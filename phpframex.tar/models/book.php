<?php
// file: models/book.php

class Book extends Model {
  protected static $table = 'book';
  
}
?>