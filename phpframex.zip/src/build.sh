cat Router.php Template.php Query.php DB.php Model.php Controller.php Input.php Cookie.php Session.php Auth.php > ../PHPFramex.php
